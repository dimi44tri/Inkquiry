ALTER TABLE `questions` ADD `title` VARCHAR( 50 ) NOT NULL ,
ADD `category` VARCHAR( 20 ) NOT NULL 