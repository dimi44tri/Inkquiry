            <div class = "navbard navbar-inverse navbar-fixed-bottom">
                  <div class="container">
                    <p class="navbar-text pull-left">Project 4</p>
                    <a href="contactus.php" class="navbar-btn btn-default btn pull-right">Contact Us</a>
                </div> 
            </div>