  			<div class="col-md-2">
              	
			<div class="well infoWell">
              <ul class="nav nav-pills nav-stacked">
                <li><a href="main.php"><i class="glyphicon glyphicon-home"></i> Home</a></li>
                <li><a href="profile.php"><i class="glyphicon glyphicon-user"></i> My Profile</a></li>
                <li><a href="whiteboard.php"><i class="glyphicon glyphicon-th-large"></i> Draw</a></li>
                <li><a href="contactus.php"><i class="glyphicon glyphicon-envelope"></i> Help</a></li>
                <li id="accordion">
                    <a data-toggle="collapse" data-parent="#accordion" href="#collapseOne">
                        Ask A Question
                    </a>
                </li>
                <ul id="collapseOne" class="nav nav-pills collapse out">
                  <li><a href="textquestion.php"><i class="glyphicon glyphicon-pencil"></i> Text Question</a></li>
                </ul>
              </ul>
            </div>
      		</div>