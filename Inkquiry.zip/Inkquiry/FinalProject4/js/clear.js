document.getElementById('clear').addEventListener('click',function(){
  context.clearRect(0,0,canvas.width,canvas.height);  
    
},false);